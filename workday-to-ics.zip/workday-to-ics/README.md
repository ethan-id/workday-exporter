# workday-exporter
A chrome extension to export workday course calendars as ics files.
